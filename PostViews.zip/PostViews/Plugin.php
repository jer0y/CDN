<?php
/**
 * Typecho 页面浏览统计 js 版
 *
 * @package PostViews
 * @author WeiCN
 * @version 1.0.0
 * @link https://cuojue.org/
 */
 class PostViews_Plugin implements Typecho_Plugin_Interface
 {

    /** @var bool 请求适配器 */
	private static $_adapter    = false;

	 /**
	 * 激活插件方法,如果激活失败,直接抛出异常
	 *
	 * @access public
	 * @return String
	 * @throws Typecho_Plugin_Exception
	 */
	 public static function activate()
	{
		Helper::addRoute('PostViews', '/PostViews', 'PostViews_Action', 'Action');
		Typecho_Plugin::factory('Widget_Archive')->footer = array('PostViews_Plugin', 'footer');
	}
	/**
	 * 禁用插件方法,如果禁用失败,直接抛出异常
	 *
	 * @static
	 * @access public
	 * @return String
	 * @throws Typecho_Plugin_Exception
	 */
	public static function deactivate()
	{
		Helper::removeRoute('PostViews');
	}
	/**
	 * 获取插件配置面板
	 *
	 * @access public
	 * @param Typecho_Widget_Helper_Form $form 配置面板
	 * @return void
	 */
	public static function config(Typecho_Widget_Helper_Form $form)
	{

	}
	/**
	 * 个人用户的配置面板
	 *
	 * @access public
	 * @param Typecho_Widget_Helper_Form $form
	 * @return void
	 */
	public static function personalConfig(Typecho_Widget_Helper_Form $form){}


	public static function footer($archive){
	?>
		<script>
		function PostViews() {
			if(typeof(cid) !== 'undefined'){
				if(cid > 0){
					$.ajax({
						type: 'Get',
						url: '/PostViews?cid='+cid,
						success: function(data) {
							var Views = data.Views;
							$('#post-views').text(Views);
						}
					});
				}
				cid = 0;
			}
		}
		PostViews();
		</script>
	<?
	}
 }
