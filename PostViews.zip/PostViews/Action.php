<?php
/**
 * PostViews Plugin
 *
 * @copyright  Copyright (c) 2020 WeiCN (https://cuojue.org)
 * @license	GNU General Public License 2.0
 * 
 */
class PostViews_Action extends Typecho_Widget implements Widget_Interface_Do
{

    /** @var bool 请求适配器 */
	private static $_adapter    = false;
	
	public function __construct($request, $response, $params = NULL)
	{
		parent::__construct($request, $response, $params);
	}

	public function cid(){
		$cid = intval($this->request->get('cid'));
		if($cid>0){
			header("content-type:application/json");
			$db = Typecho_Db::get();
			if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
				$db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 0;');
				echo json_encode(array("Views" => 0));
				exit;
			}
			$row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
			if($row && $row['views']>=0){
				$views = Typecho_Cookie::get('extend_contents_views');
				if(empty($views)){
					$views = array();
				}else{
					$views = explode(',', $views);
				}
				if(!in_array($cid,$views)){//如果cookie不存在才会加1
					$db->query($db->update('table.contents')->rows(array('views' => (int) $row['views'] + 1))->where('cid = ?', $cid));
					array_push($views, $cid);
					$views = implode(',', $views);
					Typecho_Cookie::set('extend_contents_views', $views); //记录查看cookie
				}
				$views = array("Views" => $row['views']);
				echo json_encode($views);
				exit;
			}
		}
	}

	public function action(){
		$this->on($this->request->is('cid'))->cid();
	}

}
?>
